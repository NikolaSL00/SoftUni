import { html } from "../../node_modules/lit-html/lit-html.js";
import * as gameService from "../api/game.js";
import { homeGameTemplate } from "./gameTemplate.js";

const homeTemplate = (recentGames) => html `
  <section id="welcome-world">
    <div class="welcome-message">
      <h2>ALL new games are</h2>
      <h3>Only in GamesPlay</h3>
    </div>
    <img src="./images/four_slider_img01.png" alt="hero" />

    <div id="home-page">
      <h1>Latest Games</h1>

      ${recentGames.length > 0
        ? recentGames.map((game) => homeGameTemplate(game))
        : html`<p class="no-articles">No games yet</p>`}
    </div>
  </section>
`;

export const homeView = async (ctx) => {
  const recentGames = await gameService.getRecent();
  ctx.render(homeTemplate(recentGames));
};