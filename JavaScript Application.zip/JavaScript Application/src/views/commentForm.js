import { html, nothing } from "../../node_modules/lit-html/lit-html.js";
import * as commentsService from "../api/comments.js";
import { createSubmitHandler } from "../util.js";

const formTemplate = (onSubmit) => html `
  <article class="create-comment">
    <label>Add new comment:</label>
    <form @submit=${onSubmit} class="form">
      <textarea name="comment" placeholder="Comment......"></textarea>
      <input class="btn submit" type="submit" value="Add Comment" />
    </form>
  </article>
`;

export function commentFormView(ctx, isOwner) {
    console.log(isOwner);
    if (ctx.user && !isOwner) {
        return formTemplate(createSubmitHandler(ctx, onSubmit));
    } else {
        return nothing;
    }
}

async function onSubmit(ctx, data, event) {
    const gameId = ctx.params.id;

    if (!data.comment) {
        return alert("You can not post empty comment!");
    }

    await commentsService.postComment({
        gameId,
        comment: data.comment,
    });

    event.target.reset();
    ctx.page.redirect(`/details/${gameId}`);
}