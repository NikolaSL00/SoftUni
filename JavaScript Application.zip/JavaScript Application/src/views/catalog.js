import { html } from "../../node_modules/lit-html/lit-html.js";
import * as gameService from "../api/game.js";
import { catalogGameTemplate } from "./gameTemplate.js";

const catalogTemplate = (allGames) => html `<section id="catalog-page">
  <h1>All Games</h1>

  ${allGames.length > 0
    ? allGames.map((game) => catalogGameTemplate(game))
    : html`<h3 class="no-articles">No articles yet</h3>`}
</section>`;

export const catalogView = async (ctx) => {
  const allGames = await gameService.getAll();
  ctx.render(catalogTemplate(allGames));
};